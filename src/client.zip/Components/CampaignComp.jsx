import React, { useState } from 'react';

import "./Styles/campaignList.css";

const CampaignComp = ({ campaign , handleDonate, userInDonorsCollection }) => {
    const [localDonationAmount, setLocalDonationAmount] = useState(0);
    const [donationComplete, setDonationComplete] = useState(false);

    const handleDonateClick = () => {
        handleDonate(campaign.id, localDonationAmount, campaign.name);
        setDonationComplete(true);
        setTimeout(() => {
            setLocalDonationAmount(0);
            setDonationComplete(false);
        }, 2000); 
    };

    return (
        <div className='c-render'>
            <div className='c-name-cont'><span className='name'>{campaign.name}</span></div>
            <div><strong>Description:</strong> {campaign.description}</div>
            <div><strong>Start Date:</strong> {campaign.startDate}</div>
            <div><strong>End Date:</strong> {campaign.endDate}</div>
            <div><strong>Target Amount:</strong> {campaign.targetAmount}</div>
            <div><strong>Franchise  ID:</strong> {campaign.franchiseID}</div>
            <div><strong>Collected Amount:</strong> {campaign.currentAmountRaised}</div>
            <div><strong>Status:</strong> {campaign.status}</div>

            {userInDonorsCollection && !donationComplete && (
                <div className='c-don-cont'>
                    <input className='c-donations' type="number" placeholder="Enter amount" onChange={(e) => setLocalDonationAmount(e.target.value)} />
                    <button className='c-handle-donations' onClick={handleDonateClick} disabled={localDonationAmount <= 0}>
                        Donate
                    </button>
                </div>
            )}

            {donationComplete && (
                <div className="c-loader">DONATING !!</div>
            )}
        </div>
    );
};

export default CampaignComp;
